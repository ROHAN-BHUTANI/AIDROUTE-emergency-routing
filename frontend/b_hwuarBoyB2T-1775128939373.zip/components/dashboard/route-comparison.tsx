"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { GitCompare, Zap, Shield, Clock, Route, AlertTriangle, CheckCircle } from "lucide-react"
import { cn } from "@/lib/utils"

interface RouteData {
  name: string
  eta: number
  distance: number
  riskLevel: "low" | "medium" | "high"
  recommended?: boolean
  features: string[]
}

interface RouteComparisonProps {
  hasData?: boolean
}

export function RouteComparison({ hasData }: RouteComparisonProps) {
  const routes: RouteData[] = hasData
    ? [
        {
          name: "Fastest Route",
          eta: 8,
          distance: 4.2,
          riskLevel: "medium",
          features: ["Highway access", "Minimal stops", "Heavy traffic possible"],
        },
        {
          name: "Safest Route",
          eta: 12,
          distance: 5.1,
          riskLevel: "low",
          recommended: true,
          features: ["Residential areas", "Clear conditions", "Lower risk zones"],
        },
      ]
    : []

  const getRiskStyles = (level: string) => {
    switch (level) {
      case "low":
        return {
          badge: "bg-success/10 text-success border-success/20",
          icon: "text-success",
        }
      case "medium":
        return {
          badge: "bg-warning/10 text-warning border-warning/20",
          icon: "text-warning",
        }
      case "high":
        return {
          badge: "bg-destructive/10 text-destructive border-destructive/20",
          icon: "text-destructive",
        }
      default:
        return {
          badge: "bg-muted text-muted-foreground",
          icon: "text-muted-foreground",
        }
    }
  }

  return (
    <Card className="border-border bg-card/50 backdrop-blur-sm">
      <CardHeader className="pb-4">
        <CardTitle className="flex items-center gap-2 text-lg font-semibold">
          <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-primary/10">
            <GitCompare className="h-4 w-4 text-primary" />
          </div>
          Route Comparison
        </CardTitle>
      </CardHeader>
      <CardContent>
        {routes.length > 0 ? (
          <div className="grid gap-4 lg:grid-cols-2">
            {routes.map((route) => {
              const riskStyles = getRiskStyles(route.riskLevel)
              return (
                <div
                  key={route.name}
                  className={cn(
                    "relative overflow-hidden rounded-xl border p-4 transition-all hover:border-primary/30",
                    route.recommended
                      ? "border-primary/30 bg-primary/5"
                      : "border-border bg-muted/20"
                  )}
                >
                  {route.recommended && (
                    <div className="absolute right-0 top-0">
                      <div className="flex items-center gap-1 rounded-bl-lg bg-primary px-2 py-1 text-xs font-medium text-primary-foreground">
                        <CheckCircle className="h-3 w-3" />
                        Recommended
                      </div>
                    </div>
                  )}

                  <div className="mb-4 flex items-center gap-2">
                    <div
                      className={cn(
                        "flex h-8 w-8 items-center justify-center rounded-lg",
                        route.name === "Fastest Route"
                          ? "bg-warning/10 text-warning"
                          : "bg-success/10 text-success"
                      )}
                    >
                      {route.name === "Fastest Route" ? (
                        <Zap className="h-4 w-4" />
                      ) : (
                        <Shield className="h-4 w-4" />
                      )}
                    </div>
                    <h3 className="font-semibold text-foreground">{route.name}</h3>
                  </div>

                  <div className="mb-4 grid grid-cols-3 gap-3">
                    <div className="space-y-1">
                      <div className="flex items-center gap-1 text-muted-foreground">
                        <Clock className="h-3.5 w-3.5" />
                        <span className="text-xs">ETA</span>
                      </div>
                      <p className="text-lg font-bold text-foreground">
                        {route.eta}
                        <span className="text-xs font-normal text-muted-foreground"> min</span>
                      </p>
                    </div>
                    <div className="space-y-1">
                      <div className="flex items-center gap-1 text-muted-foreground">
                        <Route className="h-3.5 w-3.5" />
                        <span className="text-xs">Distance</span>
                      </div>
                      <p className="text-lg font-bold text-foreground">
                        {route.distance}
                        <span className="text-xs font-normal text-muted-foreground"> km</span>
                      </p>
                    </div>
                    <div className="space-y-1">
                      <div className="flex items-center gap-1 text-muted-foreground">
                        <AlertTriangle className="h-3.5 w-3.5" />
                        <span className="text-xs">Risk</span>
                      </div>
                      <Badge
                        variant="outline"
                        className={cn("capitalize", riskStyles.badge)}
                      >
                        {route.riskLevel}
                      </Badge>
                    </div>
                  </div>

                  <div className="space-y-2">
                    <p className="text-xs font-medium text-muted-foreground">
                      Route Features
                    </p>
                    <ul className="space-y-1.5">
                      {route.features.map((feature, index) => (
                        <li
                          key={index}
                          className="flex items-center gap-2 text-sm text-muted-foreground"
                        >
                          <div className="h-1 w-1 rounded-full bg-muted-foreground/50" />
                          {feature}
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>
              )
            })}
          </div>
        ) : (
          <div className="flex flex-col items-center justify-center py-8 text-center">
            <div className="mb-4 flex h-12 w-12 items-center justify-center rounded-2xl border border-dashed border-border bg-muted/30">
              <GitCompare className="h-6 w-6 text-muted-foreground/50" />
            </div>
            <p className="mb-1 text-sm font-medium text-muted-foreground">
              No routes to compare
            </p>
            <p className="text-xs text-muted-foreground/70">
              Optimize a route to see fastest vs safest comparison
            </p>
          </div>
        )}
      </CardContent>
    </Card>
  )
}
