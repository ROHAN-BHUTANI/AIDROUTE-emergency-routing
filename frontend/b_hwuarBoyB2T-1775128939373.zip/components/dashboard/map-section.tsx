"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Map, Layers, ZoomIn, ZoomOut, Locate, Maximize2 } from "lucide-react"
import { Button } from "@/components/ui/button"

interface MapSectionProps {
  hasRoute?: boolean
}

export function MapSection({ hasRoute }: MapSectionProps) {
  return (
    <Card className="flex h-full flex-col border-border bg-card/50 backdrop-blur-sm">
      <CardHeader className="flex-row items-center justify-between pb-4">
        <CardTitle className="flex items-center gap-2 text-lg font-semibold">
          <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-primary/10">
            <Map className="h-4 w-4 text-primary" />
          </div>
          Route Map
        </CardTitle>
        <div className="flex items-center gap-1">
          <Button variant="ghost" size="icon" className="h-8 w-8 text-muted-foreground hover:text-foreground">
            <Layers className="h-4 w-4" />
          </Button>
          <Button variant="ghost" size="icon" className="h-8 w-8 text-muted-foreground hover:text-foreground">
            <Maximize2 className="h-4 w-4" />
          </Button>
        </div>
      </CardHeader>
      <CardContent className="relative flex-1 p-4 pt-0">
        {/* Map Placeholder - Leaflet compatible container */}
        <div 
          id="map-container"
          className="relative h-full min-h-[400px] w-full overflow-hidden rounded-xl border border-border bg-background"
        >
          {/* Grid overlay for visual effect */}
          <div 
            className="absolute inset-0 opacity-20"
            style={{
              backgroundImage: `
                linear-gradient(rgba(59, 130, 246, 0.1) 1px, transparent 1px),
                linear-gradient(90deg, rgba(59, 130, 246, 0.1) 1px, transparent 1px)
              `,
              backgroundSize: '40px 40px'
            }}
          />
          
          {/* Map visual representation */}
          <div className="absolute inset-0 flex items-center justify-center">
            {hasRoute ? (
              <div className="relative h-full w-full">
                {/* Simulated route visualization */}
                <svg className="absolute inset-0 h-full w-full" viewBox="0 0 400 300" preserveAspectRatio="xMidYMid slice">
                  {/* Route path */}
                  <path
                    d="M 50 250 Q 100 200, 150 180 T 250 120 T 350 50"
                    fill="none"
                    stroke="url(#routeGradient)"
                    strokeWidth="4"
                    strokeLinecap="round"
                    className="animate-pulse"
                  />
                  {/* Gradient definition */}
                  <defs>
                    <linearGradient id="routeGradient" x1="0%" y1="0%" x2="100%" y2="0%">
                      <stop offset="0%" stopColor="hsl(var(--primary))" />
                      <stop offset="100%" stopColor="hsl(var(--chart-2))" />
                    </linearGradient>
                  </defs>
                  {/* Start marker */}
                  <circle cx="50" cy="250" r="8" fill="hsl(var(--primary))" className="animate-pulse" />
                  <circle cx="50" cy="250" r="12" fill="none" stroke="hsl(var(--primary))" strokeWidth="2" opacity="0.5" />
                  {/* End marker */}
                  <circle cx="350" cy="50" r="8" fill="hsl(var(--destructive))" />
                  <circle cx="350" cy="50" r="12" fill="none" stroke="hsl(var(--destructive))" strokeWidth="2" opacity="0.5" />
                </svg>
                
                {/* Labels */}
                <div className="absolute bottom-4 left-4 rounded-lg bg-card/90 px-3 py-2 text-xs backdrop-blur-sm">
                  <span className="flex items-center gap-2">
                    <span className="h-2 w-2 rounded-full bg-primary" />
                    <span className="text-muted-foreground">Start: Emergency Station</span>
                  </span>
                </div>
                <div className="absolute right-4 top-4 rounded-lg bg-card/90 px-3 py-2 text-xs backdrop-blur-sm">
                  <span className="flex items-center gap-2">
                    <span className="h-2 w-2 rounded-full bg-destructive" />
                    <span className="text-muted-foreground">Destination</span>
                  </span>
                </div>
              </div>
            ) : (
              <div className="flex flex-col items-center gap-3 text-muted-foreground">
                <div className="flex h-16 w-16 items-center justify-center rounded-2xl border border-dashed border-border bg-muted/30">
                  <Map className="h-8 w-8 text-muted-foreground/50" />
                </div>
                <p className="text-sm">Enter coordinates to visualize route</p>
                <p className="text-xs text-muted-foreground/70">Leaflet map integration ready</p>
              </div>
            )}
          </div>

          {/* Map controls */}
          <div className="absolute bottom-4 right-4 flex flex-col gap-1">
            <Button
              variant="secondary"
              size="icon"
              className="h-8 w-8 bg-card/90 backdrop-blur-sm hover:bg-card"
            >
              <ZoomIn className="h-4 w-4" />
            </Button>
            <Button
              variant="secondary"
              size="icon"
              className="h-8 w-8 bg-card/90 backdrop-blur-sm hover:bg-card"
            >
              <ZoomOut className="h-4 w-4" />
            </Button>
            <Button
              variant="secondary"
              size="icon"
              className="h-8 w-8 bg-card/90 backdrop-blur-sm hover:bg-card"
            >
              <Locate className="h-4 w-4" />
            </Button>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}
