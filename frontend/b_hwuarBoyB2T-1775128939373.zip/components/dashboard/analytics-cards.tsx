"use client"

import { Card, CardContent } from "@/components/ui/card"
import { Clock, Route, AlertTriangle, MessageSquare, TrendingUp, TrendingDown } from "lucide-react"
import { cn } from "@/lib/utils"

interface AnalyticsData {
  eta: number | null
  distance: number | null
  riskLevel: "low" | "medium" | "high" | null
  recommendation: string | null
}

interface AnalyticsCardsProps {
  data: AnalyticsData
  isLoading?: boolean
}

export function AnalyticsCards({ data, isLoading }: AnalyticsCardsProps) {
  const getRiskColor = (level: string | null) => {
    switch (level) {
      case "low":
        return "text-success bg-success/10 border-success/20"
      case "medium":
        return "text-warning bg-warning/10 border-warning/20"
      case "high":
        return "text-destructive bg-destructive/10 border-destructive/20"
      default:
        return "text-muted-foreground bg-muted/10 border-muted/20"
    }
  }

  const getRiskLabel = (level: string | null) => {
    switch (level) {
      case "low":
        return "Low Risk"
      case "medium":
        return "Medium Risk"
      case "high":
        return "High Risk"
      default:
        return "—"
    }
  }

  const cards = [
    {
      title: "Estimated Time",
      value: data.eta !== null ? `${data.eta}` : "—",
      unit: "min",
      icon: Clock,
      trend: data.eta !== null ? { value: "-12%", positive: true } : null,
      description: "vs. standard route",
    },
    {
      title: "Total Distance",
      value: data.distance !== null ? `${data.distance}` : "—",
      unit: "km",
      icon: Route,
      trend: data.distance !== null ? { value: "+0.3km", positive: false } : null,
      description: "optimized path",
    },
    {
      title: "Risk Level",
      value: getRiskLabel(data.riskLevel),
      unit: "",
      icon: AlertTriangle,
      customClass: getRiskColor(data.riskLevel),
      description: "traffic & weather",
    },
  ]

  return (
    <div className="space-y-4">
      <div className="grid gap-4 sm:grid-cols-3">
        {cards.map((card) => (
          <Card
            key={card.title}
            className={cn(
              "group relative overflow-hidden border-border bg-card/50 backdrop-blur-sm transition-all hover:border-primary/30 hover:shadow-lg hover:shadow-primary/5",
              isLoading && "animate-pulse"
            )}
          >
            <CardContent className="p-5">
              <div className="flex items-start justify-between">
                <div className="space-y-3">
                  <p className="text-xs font-medium uppercase tracking-wider text-muted-foreground">
                    {card.title}
                  </p>
                  <div className="flex items-baseline gap-1">
                    <span
                      className={cn(
                        "text-3xl font-bold tracking-tight",
                        card.customClass ? card.customClass.split(" ")[0] : "text-foreground"
                      )}
                    >
                      {card.value}
                    </span>
                    {card.unit && (
                      <span className="text-sm text-muted-foreground">{card.unit}</span>
                    )}
                  </div>
                  {card.trend && (
                    <div className="flex items-center gap-1.5">
                      {card.trend.positive ? (
                        <TrendingDown className="h-3.5 w-3.5 text-success" />
                      ) : (
                        <TrendingUp className="h-3.5 w-3.5 text-warning" />
                      )}
                      <span
                        className={cn(
                          "text-xs font-medium",
                          card.trend.positive ? "text-success" : "text-warning"
                        )}
                      >
                        {card.trend.value}
                      </span>
                      <span className="text-xs text-muted-foreground">
                        {card.description}
                      </span>
                    </div>
                  )}
                  {!card.trend && (
                    <p className="text-xs text-muted-foreground">{card.description}</p>
                  )}
                </div>
                <div
                  className={cn(
                    "flex h-10 w-10 items-center justify-center rounded-xl border transition-colors",
                    card.customClass || "border-border bg-muted/30 text-muted-foreground"
                  )}
                >
                  <card.icon className="h-5 w-5" />
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Recommendation Card */}
      <Card className="border-border bg-card/50 backdrop-blur-sm">
        <CardContent className="p-5">
          <div className="flex items-start gap-4">
            <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl border border-primary/20 bg-primary/10">
              <MessageSquare className="h-5 w-5 text-primary" />
            </div>
            <div className="space-y-1">
              <p className="text-xs font-medium uppercase tracking-wider text-muted-foreground">
                AI Recommendation
              </p>
              <p className="text-sm leading-relaxed text-foreground">
                {data.recommendation || (
                  <span className="text-muted-foreground">
                    Enter route details to receive AI-powered optimization recommendations.
                  </span>
                )}
              </p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
