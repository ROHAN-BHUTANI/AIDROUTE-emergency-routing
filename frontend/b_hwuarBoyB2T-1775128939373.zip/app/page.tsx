"use client"

import { useState } from "react"
import { Sidebar } from "@/components/dashboard/sidebar"
import { InputCard } from "@/components/dashboard/input-card"
import { MapSection } from "@/components/dashboard/map-section"
import { AnalyticsCards } from "@/components/dashboard/analytics-cards"
import { RouteComparison } from "@/components/dashboard/route-comparison"
import { Activity, Bell, Search, User, Menu } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"

interface AnalyticsData {
  eta: number | null
  distance: number | null
  riskLevel: "low" | "medium" | "high" | null
  recommendation: string | null
}

export default function Dashboard() {
  const [isLoading, setIsLoading] = useState(false)
  const [hasRoute, setHasRoute] = useState(false)
  const [sidebarOpen, setSidebarOpen] = useState(false)
  const [analyticsData, setAnalyticsData] = useState<AnalyticsData>({
    eta: null,
    distance: null,
    riskLevel: null,
    recommendation: null,
  })

  const handleOptimize = async (data: {
    latitude: string
    longitude: string
    emergencyType: string
  }) => {
    setIsLoading(true)

    // Simulate API call
    await new Promise((resolve) => setTimeout(resolve, 1500))

    // Mock response data
    setAnalyticsData({
      eta: Math.floor(Math.random() * 15) + 5,
      distance: Math.round((Math.random() * 10 + 2) * 10) / 10,
      riskLevel: ["low", "medium", "high"][Math.floor(Math.random() * 3)] as
        | "low"
        | "medium"
        | "high",
      recommendation: `Based on current conditions and ${data.emergencyType || "general"} emergency protocols, we recommend taking the safest route via residential areas. Traffic is moderate with clear weather conditions. EMS units should avoid Highway 101 due to construction.`,
    })
    setHasRoute(true)
    setIsLoading(false)
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Mobile sidebar overlay */}
      {sidebarOpen && (
        <div 
          className="fixed inset-0 z-40 bg-background/80 backdrop-blur-sm lg:hidden"
          onClick={() => setSidebarOpen(false)}
        />
      )}
      
      {/* Sidebar - hidden on mobile unless open */}
      <div className={`${sidebarOpen ? 'translate-x-0' : '-translate-x-full'} lg:translate-x-0 transition-transform duration-300`}>
        <Sidebar />
      </div>

      {/* Main Content */}
      <div className="lg:pl-64 transition-all duration-300">
        {/* Top Header */}
        <header className="sticky top-0 z-30 flex h-16 items-center justify-between border-b border-border bg-background/80 px-4 sm:px-6 backdrop-blur-md">
          <div className="flex items-center gap-4">
            {/* Mobile menu button */}
            <Button 
              variant="ghost" 
              size="icon" 
              className="lg:hidden text-muted-foreground"
              onClick={() => setSidebarOpen(!sidebarOpen)}
            >
              <Menu className="h-5 w-5" />
            </Button>
            <div className="relative hidden sm:block">
              <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
              <Input
                type="search"
                placeholder="Search routes, analytics..."
                className="w-64 border-input bg-input pl-10 transition-colors focus:border-primary"
              />
            </div>
          </div>

          <div className="flex items-center gap-3">
            {/* Live Status */}
            <div className="hidden sm:flex items-center gap-2 rounded-full border border-success/30 bg-success/10 px-3 py-1.5">
              <Activity className="h-3.5 w-3.5 animate-pulse text-success" />
              <span className="text-xs font-medium text-success">System Online</span>
            </div>

            {/* Notifications */}
            <Button variant="ghost" size="icon" className="relative text-muted-foreground hover:text-foreground">
              <Bell className="h-5 w-5" />
              <span className="absolute right-1.5 top-1.5 h-2 w-2 rounded-full bg-destructive" />
            </Button>

            {/* User Menu */}
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" className="flex items-center gap-2 px-2">
                  <Avatar className="h-8 w-8">
                    <AvatarImage src="/placeholder-avatar.jpg" alt="User" />
                    <AvatarFallback className="bg-primary text-primary-foreground">
                      JD
                    </AvatarFallback>
                  </Avatar>
                  <div className="hidden text-left sm:block">
                    <p className="text-sm font-medium text-foreground">John Doe</p>
                    <p className="text-xs text-muted-foreground">Dispatcher</p>
                  </div>
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="w-48">
                <DropdownMenuLabel>My Account</DropdownMenuLabel>
                <DropdownMenuSeparator />
                <DropdownMenuItem>
                  <User className="mr-2 h-4 w-4" />
                  Profile
                </DropdownMenuItem>
                <DropdownMenuItem>Settings</DropdownMenuItem>
                <DropdownMenuSeparator />
                <DropdownMenuItem className="text-destructive">
                  Log out
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        </header>

        {/* Page Content */}
        <main className="p-4 sm:p-6">
          {/* Page Title */}
          <div className="mb-6">
            <h1 className="text-2xl font-bold tracking-tight text-foreground">
              Emergency Response Dashboard
            </h1>
            <p className="mt-1 text-sm text-muted-foreground">
              AI-powered route optimization for faster emergency response times
            </p>
          </div>

          {/* Dashboard Grid */}
          <div className="grid gap-6 lg:grid-cols-3">
            {/* Left Column - Input & Analytics */}
            <div className="space-y-6 lg:col-span-1">
              <InputCard onOptimize={handleOptimize} isLoading={isLoading} />
              <AnalyticsCards data={analyticsData} isLoading={isLoading} />
            </div>

            {/* Right Column - Map & Route Comparison */}
            <div className="space-y-6 lg:col-span-2">
              <MapSection hasRoute={hasRoute} />
              <RouteComparison hasData={hasRoute} />
            </div>
          </div>
        </main>
      </div>
    </div>
  )
}
